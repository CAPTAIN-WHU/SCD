This the official implementation version of Separated Kappa (SeK), which requires prediction maps with size of H x W x Num_class as the input and calculates the SeK.

Put the model predictions in INFER_DIR and extract the label files in LABEL_DIR. The the evaluation results can be obtained by running the Metric.py.

